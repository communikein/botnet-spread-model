# Simple file I/O in Python for CSV files
#
# Copyright 2013 Hiroki Sayama
# sayama@binghamton.edu
#
# Ported to Python 3 by Przemyslaw Szufel & Bogumil Kaminski 2013
# {pszufe, bkamins}@sgh.waw.pl

import csv

data = [["Hello", "World"], [1,2,3], ["The", "last", "row"]]


# writing to file

f = open("myfile.csv", "w", encoding='utf-8', newline='')
fcsv = csv.writer(f, delimiter=',')

for row in data:
    fcsv.writerow(row)

f.close()

# reading from file

f = open("myfile.csv", "r", encoding='utf-8')
fcsv = csv.reader(f)

for row in fcsv:
    print (row)

f.close()
