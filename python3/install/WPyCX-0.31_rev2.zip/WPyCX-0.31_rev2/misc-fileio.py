# Simple file I/O in Python
#
# Copyright 2008-2012 Hiroki Sayama
# sayama@binghamton.edu
#
# Ported to Python 3 by Przemyslaw Szufel & Bogumil Kaminski 2013
# {pszufe, bkamins}@sgh.waw.pl

# writing to file

f = open("myfile.txt", "w")

f.write("Hello\n")
f.write("This is a second line\n")
f.write("Bye\n")

f.close()

# reading from file

f = open("myfile.txt", "r")

for row in f:
    print(row, end=" ")
    # The last comma is to prevent automatic line break

f.close()
