# Simple CA simulator in Python
#
# *** Droplet Rule ***
#
# Copyright 2008-2012 Hiroki Sayama
# sayama@binghamton.edu
#
# Ported to Python 3 and added parameter setters
# by Przemyslaw Szufel & Bogumil Kaminski
# {pszufe, bkamins}@sgh.waw.pl

import matplotlib
matplotlib.use('qt4agg')

import pylab as PL
import random as RD
import scipy as SP

RD.seed()

width = 50
height = 50
initProb = 0.25

def initProbF (val=initProb):
    """
    Population size.
The parameter change is effective only when model is reset.
    """
    global initProb
    initProb = val
    return val

def init():
    global time, config, nextConfig

    time = 0

    config = SP.zeros([height, width])
    for x in range(width):
        for y in range(height):
            if RD.random() < initProb:
                state = 1
            else:
                state = 0
            config[y, x] = state

    nextConfig = SP.zeros([height, width])

def draw():
    PL.cla()
    PL.pcolor(config, vmin = 0, vmax = 1, cmap = PL.cm.binary)
    PL.axis('image')
    PL.title('t = ' + str(time))

def step():
    global time, config, nextConfig

    time += 1

    for x in range(width):
        for y in range(height):
            state = config[y, x]
            numberOfPanicky = 0
            for dx in range(-1, 2):
                for dy in range(-1, 2):
                    numberOfPanicky += config[(y+dy)%height, (x+dx)%width]
            if state == 0 and numberOfPanicky >= 4:
                state = 1
            elif state == 1 and numberOfPanicky <= 3:
                state = 0
            nextConfig[y, x] = state

    config, nextConfig = nextConfig, config

import pycxsimulator
pycxsimulator.GUI(parameterSetters = [initProbF]).start(func=[init,draw,step])
