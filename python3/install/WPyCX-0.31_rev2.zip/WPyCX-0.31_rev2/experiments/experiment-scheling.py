# *** Simple CA simulator in Python ***
#
# *** Schelling model ***
#
# Copyright 2013 Przemyslaw Szufel & Bogumil Kaminski
# {pszufe, bkamins}@sgh.waw.pl


import collections
import random
import numpy
import scipy.interpolate
import matplotlib.cm
import matplotlib.pyplot as plt
import pycxexperimenter
import paramgen

def init(job):
    """
    Schelling's segregation model (1971)
    """
    global config, agents, empty
    global time, threshold
    global percent_unhappy, percent_similar

    agents = list()
    empty = list()
    percent_unhappy = float('nan')
    percent_similar = float('nan')
    time = 0
    density = job["density"]
    threshold = job["threshold"]
    job_id = job["job_id"]
    rep = job["rep_id"]

    start_sim = "\t{}\t{}\t{:.2%}\t{:.2%}".format(job_id, rep,
                                                  density, threshold)
    print(start_sim, end="\t")
    output.append([job_id, density, threshold])

    config = numpy.zeros([height, width])
    for x in range(width):
        for y in range(height):
            if random.random() < density:
                agents.append((y, x))
                if random.random() < 0.5:
                    config[y, x] = 1
                else:
                    config[y, x] = -1
            else:
                empty.append((y, x))

def step():
    global config, agents, empty, percent_unhappy, percent_similar, time

    percent_unhappy = 0.0
    percent_similar = 0.0
    time += 1

    sequence = list(range(len(agents)))
    random.shuffle(sequence)
    for i in sequence:
        agent = agents[i]
        y, x = agent
        state = config[y, x]
        if state == 0:
            continue
        similar = 0
        total = 0
        for dx in range(-1, 2):
            for dy in range(-1, 2):
                if not ((dx == 0) and (dy == 0)):
                    v = config[(y + dy)%height, (x+dx)%width]
                    if (v != 0):
                        total += 1
                    if (v == state):
                        similar += 1
        if (total == 0):
            percent_similar += 1
        else:
            percent_similar += similar / (1.0*total)
        if (similar < threshold * total):
            percent_unhappy += 1
            newpos = random.randrange(len(empty))
            new_y, new_x = empty[newpos]
            config[new_y, new_x] = state
            agents[i] = empty[newpos]
            config[y, x] = 0
            empty[newpos] = agent
    percent_unhappy /= (1.0*len(agents))
    percent_similar /= (1.0*len(agents))

def stop():
    global output
    if time > 100 or percent_unhappy == 0:
        end_sim = "{:.2%}\t{:.2%}\t{}".format(percent_unhappy,
                                              percent_similar, time)
        print(end_sim)
        output[-1].append(percent_similar)
        return True
    return False

def worker(design, title):
    global figurecount, output

    figurecount += 1
    print("Doing:", title, "\n\tjob\trep\tdens\tthresh\tunhap%\tsimil%\ttime")
    output = []
    pycxexperimenter.run(design, init, step, stop, replicates, "seed2")

    summary = {}
    for job_id, density, threshold, similar in output:
        try:
            density_s, threshold_s, similar_s, n_s = summary[job_id]
            if density != density_s or threshold != threshold_s:
                Exception("Unexpected error in summary")
            summary[job_id] = (density, threshold, similar_s + similar, n_s + 1)
        except:
            summary[job_id] = (density, threshold, similar, 1)

    for job_id in summary:
        density_s, threshold_s, similar_s, n_s = summary[job_id]
        summary[job_id] = (density_s, threshold_s, similar_s / n_s)

    density, threshold, similar = zip(*summary.values())
    plt.figure(figurecount)
    plt.subplot(121)
    plt.scatter(density, threshold, 300, similar,
                vmin = 0.7, vmax = 1, cmap = matplotlib.cm.Spectral)
    plt.xlim(0.27, 0.73)
    plt.ylim(0.28, 0.72)
    plt.xlabel("density")
    plt.ylabel("threshold")
    plt.title(title + ": sample")

    plt.subplot(122)
    grid_x, grid_y = numpy.mgrid[0.3:0.7:10j, 0.3:0.7:10j]
    grid_z = scipy.interpolate.griddata(numpy.array([density, threshold]).T,
        numpy.array(similar), (grid_x, grid_y), method="cubic")
    plt.imshow(grid_z.T, extent=(0.3,0.7,0.3,0.7), origin="lower",
               vmin = 0.7, vmax = 1, cmap = matplotlib.cm.Spectral)
    plt.xlabel("density")
    plt.ylabel("threshold")
    plt.title(title + ": interpolate")
    plt.colorbar().set_label("similar%")

# simulation execution
random.seed("seed1")
width = 25      # width of Schelling grid
height = 25     # height of Schelling grid
n = 8           # granularity of simulation on density/threshold dimension
replicates = 5  # number of replications per simulation design
figurecount = 0 # utility figure counter for plotting

params = collections.OrderedDict()

params["density"] = list(numpy.linspace(0.3, 0.7, n))
params["threshold"] = list(numpy.linspace(0.3, 0.7, n))
worker(paramgen.full_factorial_design(params), "Full factorial design")

params["density"] = lambda x: random.uniform(0.3, 0.7)
params["threshold"] = lambda x: random.uniform(0.3, 0.7)
worker(paramgen.latin_hypercube_design(params, n * n), "Random design")

params["density"] = lambda x: paramgen.map_float(0.3, 0.7, x)
params["threshold"] = lambda x: paramgen.map_float(0.3, 0.7, x)
worker(paramgen.latin_hypercube_design(params, n * n), "Latin hypercube design")

matplotlib.pyplot.show()