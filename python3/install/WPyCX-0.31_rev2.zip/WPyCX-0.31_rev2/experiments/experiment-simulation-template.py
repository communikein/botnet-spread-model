# *** Template for experiment run ***
#
# Copyright 2013 Przemyslaw Szufel & Bogumil Kaminski
# {pszufe, bkamins}@sgh.waw.pl

# functions can use global variable run_time defined by run

def init(job):
    # initialize system states using parameters from job
    # use 'global' to define global variables
    

def step():
    # update system states for one discrete time step
    # use 'global' to modify global variables

def stop():
    # simulation stopping condition
    # should obtain simulation time parameter
    
import paramgen
design = # define experiment design

import pycxexperimenter
pycxexperimenter.run(design, init, step, stop)
