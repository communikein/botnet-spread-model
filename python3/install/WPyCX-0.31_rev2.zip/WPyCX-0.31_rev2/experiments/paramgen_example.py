﻿# *** Library for experiment designs generation ***
#
# Copyright 2013 Przemyslaw Szufel & Bogumil Kaminski
# {pszufe, bkamins}@sgh.waw.pl

import collections
import random
import paramgen

print("Example usage of design generators\n")
print("Full factorial design")
x = collections.OrderedDict()
x["v1"] = [1, 2, 3, 4]
x["v2"] = ["a", "b", "c"]
for y in paramgen.full_factorial_design(x):
    print(" ", y)

print("\n\nRandom design")
x = collections.OrderedDict()
x["v1"] = lambda: random.choice(["a", "b", "c"])
x["v2"] = lambda: random.random()
for y in paramgen.random_design(x, 10):
    print(" ", y)

print("\n\nLatin hypercube design 1")
x = collections.OrderedDict()
x["v1"] = lambda x: paramgen.map_list(["a", "b", "c"], x)
x["v2"] = lambda x: paramgen.map_list(list(range(4)), x)
for y in paramgen.latin_hypercube_design(x, 12):
    print(" ", y)

print("\n\nLatin hypercube design 2")
x = collections.OrderedDict()
x["v1"] = lambda x: paramgen.map_list(["a", "b", "c"], x)
x["v2"] = lambda x: paramgen.map_float(1, 4, x)
for y in paramgen.latin_hypercube_design(x, 4):
    print(" ", y)
