# *** Simple experiment design example ***
#
# Copyright 2013 Przemyslaw Szufel & Bogumil Kaminski
# {pszufe, bkamins}@sgh.waw.pl

import random as RD
import networkx as NX
import collections
import numpy as NP
import matplotlib.pyplot as plt
import pycxexperimenter
import paramgen

state = None

def init(job):
    global state

    class State:
        pass

    state = State()
    state.n = job["n"]
    state.k = job["k"]
    state.prob = job["prob"]
    state.runs = job["runs"]
    state.apl = 0
    state.i = 0

    print("Starting k = {}, prob = {}".format(state.k, state.prob))

def step():
    global state
    state.i += 1
    print("*", end="")
    while True:
        try:
            G = NX.watts_strogatz_graph(state.n, state.k, state.prob)
            state.apl += NX.average_shortest_path_length(G) / state.runs
            break
        except:
            pass # retry graph generation if not connected

def stop():
    global state
    if state.i < state.runs:
        return False
    else:
        print()
        try:
            plots[state.k].append(state.apl)
        except:
            plots[state.k] = [state.apl]
        return True

# main body of simulation
params = collections.OrderedDict()
# neighbour size
params["k"] = [4, 6, 8, 10]
# rewire probability
params["prob"] = list(NP.linspace(0, 1, 11))
# number of replicates
params["runs"] = [20]
# grph size
params["n"] = [50]
design = paramgen.full_factorial_design(params)

plots = collections.OrderedDict()
pycxexperimenter.run(design, init, step, stop)
for k in params["k"]:
    plt.plot(params["prob"], plots[k])
plt.ylabel("average shortest path length")
plt.xlabel('prob')
plt.legend(params["k"])
plt.show()
