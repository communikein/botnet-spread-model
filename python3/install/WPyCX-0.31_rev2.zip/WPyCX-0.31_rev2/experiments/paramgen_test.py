﻿# *** Library for experiment designs generation ***
#
# Copyright 2013 Przemyslaw Szufel & Bogumil Kaminski
# {pszufe, bkamins}@sgh.waw.pl

import matplotlib.pyplot as plt
import scipy.stats
import sys
import collections
import random
import numpy
import paramgen

def chisq_test(design):
    x = numpy.zeros((len(design), 2))
    for i in range(len(design)):
        x[i,:] = list(design[i].values())[:2]
    x = (10 * x).astype(int)
    x = x[:,0] + 10 * x[:,1]
    x = x.astype(int)
    bins = numpy.zeros(100)
    for v in x:
        bins[v] += 1
    return scipy.stats.chisquare(bins)

def run(design, n, k, fun):
    result = []
    for i in range(n):
        val = chisq_test(fun(design, k))[0]
        result.append(val)
        print("*", end="")
        if i % 50 == 49:
            print(" ", i + 1)
        sys.stdout.flush()
    else:
        print()
    return result


print("Comparison of design generators")

random.seed(1)
n = 500
k = 1000
x = collections.OrderedDict()
x["v1"] = lambda: random.random()
x["v2"] = lambda: random.random()
print("Random design")
r = run(x, n, k, paramgen.random_design)

x["v1"] = lambda x: paramgen.map_float(0, 1, x)
x["v2"] = lambda x: paramgen.map_float(0, 1, x)
print("Latin hypercube design")
h = run(x, n, k, paramgen.latin_hypercube_design)

plt.hist(r, 20, normed = 1, facecolor = "green", alpha = 0.5,
         label="random")
plt.hist(h, 20, normed = 1, facecolor = "blue", alpha = 0.5,
         label = "latin hypercube")
rv=scipy.stats.chi2(99)
x=numpy.linspace(min(min(r), min(h)), max(max(r), max(h)))
chi2pdf=rv.pdf(x)
plt.plot(x,chi2pdf, 'r--', linewidth=1, label = r"$\chi^2$, df = 99")
plt.legend()
plt.title("Distribution of chsquare statistics")
plt.show()
