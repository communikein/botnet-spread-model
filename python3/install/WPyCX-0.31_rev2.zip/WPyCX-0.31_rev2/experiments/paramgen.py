﻿# *** Library for experiment designs generation ***
#
# Copyright 2013 Przemyslaw Szufel & Bogumil Kaminski
# {pszufe, bkamins}@sgh.waw.pl

import collections
import random

def full_factorial_design(parameters, job_id_name = "job_id"):
    if not isinstance(parameters, collections.OrderedDict):
        raise Exception("parameters must be OrderedDict")

    counter = [0] * len(parameters)
    maxcounter = []

    for dimension in parameters:
        if not isinstance(parameters[dimension], list):
            raise Exception("dimension must be a list")
        if dimension == job_id_name:
            raise Exception("dimension name equal to job_id_name")
        maxcounter.append(len(parameters[dimension]))
    result = []
    go = True
    job_id = 0
    while go:
        job_id += 1
        job = collections.OrderedDict()
        i = 0
        for dimension in parameters:
            job[dimension] = parameters[dimension][counter[i]]
            i += 1
        job[job_id_name] = job_id
        result.append(job)
        for i in range(len(parameters) - 1, -1, -1):
            counter[i] += 1
            if counter[i] == maxcounter[i]:
                counter[i] = 0
                if (i == 0):
                    go = False
            else:
                break
    return result

def random_design(parameters, times = 1, job_id_name = "job_id"):
    if not isinstance(times, int ):
        raise Exception("times must be intiger")
    if times < 1:
        raise Exception("times must be positive")
    if not isinstance(parameters, collections.OrderedDict):
        raise Exception("parameters must be OrderedDict")
    for dimension in parameters:
        if not hasattr(parameters[dimension], '__call__'):
            raise Exception("dimension must be a function")
        if dimension == job_id_name:
            raise Exception("dimension name equal to job_id_name")
    result = []
    for job_id in range(1, times + 1):
        job = collections.OrderedDict()
        i = 0
        for dimension in parameters:
            job[dimension] = parameters[dimension]()
            i += 1
        job[job_id_name] = job_id
        result.append(job)
    return result

# if parameters use lists then
# n is recommended to be least common multiple of list lengths
def latin_hypercube_design(parameters, n = 1, job_id_name = "job_id"):
    if not isinstance(n, int):
        raise Exception("n must be intiger")
    if n < 1:
        raise Exception("n must be positive")
    if not isinstance(parameters, collections.OrderedDict):
        raise Exception("parameters must be OrderedDict")
    for dimension in parameters:
        if not hasattr(parameters[dimension], '__call__'):
            raise Exception("dimension must be a function")
        if dimension == job_id_name:
            raise Exception("dimension name equal to job_id_name")
    design = []
    for i in range(len(parameters)):
        x = list(range(n))
        random.shuffle(x)
        for i in range(len(x)):
            x[i] = (x[i] + random.random()) / n
        design.append(x)
    i = 0
    for dimension in parameters:
        for j in range(len(design[i])):
            design[i][j] = parameters[dimension](design[i][j])
        i += 1
    result = []
    for job_id in range(len(design[1])):
        job = collections.OrderedDict()
        i = 0
        for dimension in parameters:
            job[dimension] = design[i][job_id]
            i += 1
        job[job_id_name] = job_id + 1
        result.append(job)
    return result

def map_list(l, x):
    if not isinstance(l, list):
        raise Exception("l must be list")
    if not isinstance(x, float):
        raise Exception("x must be float")
    if not ((x <= 1) and (x > 0)):
        raise Exception("x must be in the interval [0,1[")
    return l[int(x * len(l))]

def map_float(min, max, x):
    if not isinstance(min, (float, int)):
        raise Exception("min must be a number")
    if not isinstance(max, (float, int)):
        raise Exception("max must be a number")
    return min + x * (max - min)
