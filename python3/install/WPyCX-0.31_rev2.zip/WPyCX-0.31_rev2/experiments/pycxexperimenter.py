# *** Engine to run experiments ***
#
# Copyright 2013 Przemyslaw Szufel & Bogumil Kaminski
# {pszufe, bkamins}@sgh.waw.pl

import random

# defines global variable run_time
def run(design, init, step, stop, rep = 1,
        seed = None, crn = False,
        rep_id_name = "rep_id", seed_id_name = "seed_id"):
    if not hasattr(init, '__call__'):
        raise Exception("init must be a function")
    if not hasattr(step, '__call__'):
        raise Exception("step must be a function")
    if not hasattr(stop, '__call__'):
        raise Exception("stop must be a function")
    if not isinstance(rep, int):
        raise Exception('rep must be integer')
    if rep < 1:
        raise Exception('rep must be positive')
    if not isinstance(crn, bool):
        raise Exception('crn must be boolean')
    random.seed(seed)
    seeds = list()
    for i in range(rep):
        if crn:
            seeds.append(random.random())
        else:
            x = list()
            for j in range(len(design)):
                x.append(random.random())
            seeds.append(x)
    for i in range(rep):
        j = 0
        for job in design:
            local_job = job.copy()
            if seed_id_name in local_job:
                raise Exception("seed_id_name in job names")
            if crn:
                random.seed(seeds[i])
                local_job[seed_id_name] = seeds[i]
            else:
                random.seed(seeds[i][j])
                local_job[seed_id_name] = seeds[i][j]
            if rep_id_name in local_job:
                raise Exception("rep_id_name in job names")
            local_job[rep_id_name] = i + 1
            init(local_job)
            while not stop():
                step()
            j += 1
