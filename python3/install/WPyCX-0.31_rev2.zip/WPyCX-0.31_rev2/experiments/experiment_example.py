# *** Example of experiment run ***
#
# Copyright 2013 Przemyslaw Szufel & Bogumil Kaminski
# {pszufe, bkamins}@sgh.waw.pl

import collections
import math
import numpy
import random
import scipy.stats
import pycxexperimenter
import paramgen
import matplotlib.pyplot as plt

def init(job):
    global fun, name, time, output
    fun, name =  job["fun"]
    time = 0
    output[name] = []
    print("Function: ", name)

def step():
    global time, output
    time += 1
    if time % 100 == 0:
        print("*", end="")
    output[name].append(fun(random.random()))

def stop():
    if (time < n):
        return False
    print()
    return True

fun1 = "2exp(x)"
fun2 = "exp(x)+1.7"
x = collections.OrderedDict()
x["fun"] = [[(lambda x: 2*math.exp(x)), fun1],
            [(lambda x: math.exp(x)+1.7), fun2]]

def summary(color, label):
    v1 = numpy.array(output[fun1])
    v2 = numpy.array(output[fun2])

    print("\nResults:")
    print("{:<12}: {}".format(fun1, numpy.mean(v1)))
    print("{:<12}: {}".format(fun2, numpy.mean(v2)))
    print("{:<12}: {}".format("difference",numpy.mean(v1-v2)))
    print("{:<12}: {}".format("sd",numpy.std(v1-v2)))
    print("{0:<12}: {1[0]:.4} (p-value: {1[1]:.4})".format("t-test",scipy.stats.ttest_1samp(v1-v2, 0)))
    plt.hist(v1 - v2, 20, normed = 1, facecolor = color, alpha = 0.5,
         label= label)


design = paramgen.full_factorial_design(x)

n = 20000
output = {}
print("Common Random Numbers: True")
pycxexperimenter.run(design, init, step, stop,
                     seed = 2, crn = True)
summary("green", "True")

output = {}
print("\nCommon Random Numbers: False")
pycxexperimenter.run(design, init, step, stop,
                     seed = 2, crn = False)
summary("blue", "False")

plt.legend()
plt.title("Distribution of differences")
plt.show()
